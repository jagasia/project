import { Component, DoCheck, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit, DoCheck, OnChanges {
  status:string="login";
  constructor(private us:UserService, private ar:ActivatedRoute, private router:Router) { }
  ngOnChanges(changes: SimpleChanges): void {
    throw new Error('Method not implemented.');
  }
  ngDoCheck(): void {
    // console.log("ngDoCheck started");
    this.us.loginStatus().subscribe((data)=>{
      // console.log(data);
      if(data==null)
        this.status="login";
      else
      {
        this.status="logout";
       
      } 
        
    });
    // console.log("ngDoCheck ends");
  }

  ngOnInit(): void {
    //check the login status and update the this.status value

  }

}
