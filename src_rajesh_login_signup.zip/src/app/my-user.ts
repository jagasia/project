export class MyUser {
    username:string;
    password:string;
}
