import { MyUser } from './my-user';

describe('MyUser', () => {
  it('should create an instance', () => {
    expect(new MyUser()).toBeTruthy();
  });
});
